INSERT INTO liyacd.company_exchange (company_id, stock_exchange_id, stock_code) VALUES (1, 1, 'company1-1');
INSERT INTO liyacd.company_exchange (company_id, stock_exchange_id, stock_code) VALUES (2, 2, 'company2-1');
INSERT INTO liyacd.company_exchange (company_id, stock_exchange_id, stock_code) VALUES (3, 3, 'company3-1');
INSERT INTO liyacd.company_exchange (company_id, stock_exchange_id, stock_code) VALUES (4, 4, 'company4-1');
INSERT INTO liyacd.company_exchange (company_id, stock_exchange_id, stock_code) VALUES (5, 5, 'company5-1');