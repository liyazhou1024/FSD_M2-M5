INSERT INTO liyacd.exchange (id, name, contact_address, brief, remarks) VALUES (1, 'HKEX', 'loction for HKEX', 'Hong Kong', 'HKEX');
INSERT INTO liyacd.exchange (id, name, contact_address, brief, remarks) VALUES (2, 'NASDAQ', 'location for NASDAQ', 'NASDAQ', 'NASDAQ');
INSERT INTO liyacd.exchange (id, name, contact_address, brief, remarks) VALUES (3, 'NYSE', 'location for NYSE', 'New York Stock Exchange', 'NYSE');
INSERT INTO liyacd.exchange (id, name, contact_address, brief, remarks) VALUES (4, 'SN', 'location for shenzhen', 'shenzhen', 'SN');
INSERT INTO liyacd.exchange (id, name, contact_address, brief, remarks) VALUES (5, 'SH', 'location for shanghai', 'shanghai', 'SH');