INSERT INTO liyacd.sector (id, name, brief) VALUES (1, 'sector1', 'sector1');
INSERT INTO liyacd.sector (id, name, brief) VALUES (2, 'sector2', 'sector2');
INSERT INTO liyacd.sector (id, name, brief) VALUES (3, 'sector3', 'sector3');
INSERT INTO liyacd.sector (id, name, brief) VALUES (4, 'sector4', 'sector4');
INSERT INTO liyacd.sector (id, name, brief) VALUES (5, 'sector5', 'sector5');