INSERT INTO liyacd.user (id, username, password, mobile_number, is_admin, confirmed) VALUES (5, 'admin', 'admin', '12345678', 'Y', 'Y');
INSERT INTO liyacd.user (id, username, password, mobile_number, is_admin, confirmed) VALUES (6, 'user', 'user', '123456', 'N', 'Y');
INSERT INTO liyacd.user (id, username, password, mobile_number, is_admin, confirmed) VALUES (7, 'root', 'root', '3267889', 'Y', 'Y');
INSERT INTO liyacd.user (id, username, password, mobile_number, is_admin, confirmed) VALUES (8, 'user1', 'user2', '8995434', 'N', 'Y');
INSERT INTO liyacd.user (id, username, password, mobile_number, is_admin, confirmed) VALUES (9, 'admin', '21232f297a57a5a743894a0e4a801fc3', '5678', 'Y', 'Y');
INSERT INTO liyacd.user (id, username, password, mobile_number, is_admin, confirmed) VALUES (10, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', '45678', 'N', 'Y');