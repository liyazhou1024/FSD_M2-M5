create schema if not exists liyacd collate latin1_swedish_ci;

create table if not exists exchange
(
	id int unsigned auto_increment
		primary key,
	name varchar(255) not null,
	contact_address varchar(255) not null,
	brief varchar(255) not null,
	remarks varchar(255) null
)
charset=utf8;

create table if not exists ipo_detail
(
	id int unsigned auto_increment
		primary key,
	stock_exchange_id int unsigned not null,
	stock_code varchar(10) not null,
	price_per_share decimal(20,2) not null,
	number_of_shares int not null,
	open_date_time datetime not null,
	remarks varchar(255) null
)
charset=utf8;

create table if not exists sector
(
	id int unsigned auto_increment
		primary key,
	name varchar(255) not null,
	brief varchar(255) not null
)
charset=utf8;

create table if not exists company
(
	id int unsigned auto_increment
		primary key,
	name varchar(255) not null,
	sector_id int unsigned not null,
	turnover decimal(20,2) not null,
	ceo varchar(255) not null,
	board_of_directors varchar(255) not null,
	listed_in_stock_exchanges char not null,
	brief_writeup varchar(255) null,
	deactivated char not null,
	constraint company_ibfk_1
		foreign key (sector_id) references sector (id)
			on update cascade on delete cascade
)
charset=utf8;

create index sector_id
	on company (sector_id);

create table if not exists company_exchange
(
	company_id int unsigned not null,
	stock_exchange_id int unsigned not null,
	stock_code varchar(10) not null,
	primary key (company_id, stock_exchange_id),
	constraint stock_code
		unique (stock_code),
	constraint company_exchange_ibfk_1
		foreign key (company_id) references company (id)
			on update cascade on delete cascade,
	constraint company_exchange_ibfk_2
		foreign key (stock_exchange_id) references exchange (id)
			on update cascade on delete cascade
)
charset=utf8;

create index stock_exchange_id
	on company_exchange (stock_exchange_id);

create table if not exists stock_price
(
	id int unsigned auto_increment
		primary key,
	stock_exchange_id int unsigned not null,
	stock_code varchar(10) not null,
	price decimal(20,2) not null,
	date date not null,
	time time not null,
	constraint stock_price_ibfk_1
		foreign key (stock_exchange_id) references company_exchange (stock_exchange_id)
			on update cascade on delete cascade,
	constraint stock_price_ibfk_2
		foreign key (stock_code) references company_exchange (stock_code)
			on update cascade on delete cascade
)
charset=utf8;

create index stock_code
	on stock_price (stock_code);

create index stock_exchange_id
	on stock_price (stock_exchange_id);

create table if not exists user
(
	id int unsigned auto_increment
		primary key,
	username varchar(255) not null,
	password varchar(255) not null,
	mobile_number varchar(255) null,
	is_admin char not null,
	confirmed char not null
)
charset=utf8;

