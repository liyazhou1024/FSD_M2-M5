package pers.liyacd.pojo;

import pers.liyacd.domain.IpoDetail;
import pers.liyacd.domain.Company;

public class AddCompanyRequest {
    private Company company;
//    private IpoDetail ipoDetail;

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

//    public IpoDetail getIpoDetail() {
//        return ipoDetail;
//    }
//
//    public void setIpoDetail(IpoDetail ipoDetail) {
//        this.ipoDetail = ipoDetail;
//    }
}
