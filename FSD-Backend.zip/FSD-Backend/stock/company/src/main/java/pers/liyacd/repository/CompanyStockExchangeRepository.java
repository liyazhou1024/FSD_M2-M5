package pers.liyacd.repository;

import pers.liyacd.domain.CompanyStockExchange;
import pers.liyacd.domain.SCEKey;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CompanyStockExchangeRepository extends JpaRepository<CompanyStockExchange, SCEKey> {

    List<CompanyStockExchange> findByStockExchangeId(int id);

    List<CompanyStockExchange> findByStockCode(String stockCode);

    List<CompanyStockExchange>  findByCompanyId(int companyId);
}