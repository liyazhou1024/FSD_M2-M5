package pers.liyacd.service;

import pers.liyacd.domain.IpoDetail;

import java.util.List;

public interface IpoService {

    boolean updateIpo(IpoDetail ipoDetail) throws Exception;

    List<IpoDetail> viewPlannedIpo();

    IpoDetail findIpoByCompanyId(int companyId) throws Exception;
}
