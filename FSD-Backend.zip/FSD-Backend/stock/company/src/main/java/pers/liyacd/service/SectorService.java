package pers.liyacd.service;

import pers.liyacd.domain.Sector;

import java.util.List;

public interface SectorService {

    List<Sector> findAll();
}
