package pers.liyacd.service;

import pers.liyacd.domain.Sector;
import pers.liyacd.repository.SectorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SectorServiceImpl implements SectorService {

    @Autowired
    private SectorRepository sectorRepo;

    @Override
    public List<Sector> findAll() {
        return sectorRepo.findAll();
    }
}
