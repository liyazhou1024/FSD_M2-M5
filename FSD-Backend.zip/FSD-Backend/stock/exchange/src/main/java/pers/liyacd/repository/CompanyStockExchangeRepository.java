package pers.liyacd.repository;

import pers.liyacd.domain.CompanyExchange;
import pers.liyacd.domain.SCEKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CompanyStockExchangeRepository extends JpaRepository<CompanyExchange, SCEKey> {

    List<CompanyExchange> findByCompanyId(int companyId);

    List<CompanyExchange> findByStockExchangeId(int stockExchangeId);

    List<CompanyExchange> findByStockCode(String stockCode);

    @Query("FROM CompanyExchange cse WHERE cse.stockExchangeId = :stockExchangeId " +
            "AND cse.companyId = :companyId1 OR cse.companyId = :companyId2")
    List<CompanyExchange> findByStockExchangeIdAndCompanyIds(@Param("stockExchangeId") int stockExchangeId,
                                                             @Param("companyId1") int companyId1,
                                                             @Param("companyId2") int companyId2);

}