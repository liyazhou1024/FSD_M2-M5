package pers.liyacd.controller;

import pers.liyacd.domain.User;
import pers.liyacd.pojo.LoginResponse;
import pers.liyacd.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public LoginResponse login(@RequestBody User user) throws Exception {
        return userService.login(user);
    }

    @PostMapping("/update")
    public boolean updateUser(@RequestBody User user) throws Exception {
        return userService.updateUser(user);
    }

    @GetMapping("/find-by-id")
    public User findUserById(@RequestParam int id) {
        return userService.findUserById(id);
    }

    @GetMapping("/list-all")
    public List<User> findAll() {
        return userService.findAll();
    }

}
