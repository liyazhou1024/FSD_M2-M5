package pers.liyacd.service;

import pers.liyacd.domain.User;
import pers.liyacd.pojo.LoginResponse;

import java.util.List;

public interface UserService {

    int register(User user) throws Exception;

    boolean confirmRegistration(User user) throws Exception;

    List<User> findAll();

    User findUserById(int id);

    LoginResponse login(User user) throws Exception;

    boolean updateUser(User user) throws Exception;
}
