package pers.liyacd.service;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import pers.liyacd.domain.User;
import pers.liyacd.pojo.LoginResponse;
import pers.liyacd.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Value("${liyacd.registration-confirm-url}")
    private String registrationConfirmUrl;

    @Autowired
    private UserRepository userRepo;

    @Override
    public int register(User user) throws Exception {
        List<User> userList = userRepo.findByUsername(user.getUsername());
        if (!userList.isEmpty()) {
            throw new Exception("User with username \"" + user.getUsername() + "\" already exists in our system.");
        }
        userRepo.save(user);
        return user.getId();
    }

    @Override
    public boolean confirmRegistration(User user) throws Exception {
        User u = userRepo.findUserById(user.getId());
        if (u.getConfirmed()) {
            throw new Exception("This user has already confirmed the registration.");
        }
        u.setPassword(user.getPassword());
        u.setConfirmed(true);
        userRepo.save(u);
        return true;
    }

    @Override
    public List<User> findAll() {
        return userRepo.findAll();
    }

    @Override
    public User findUserById(int id) {
        return userRepo.findUserById(id);
    }

    public String getToken(User user) {
        Date date = new Date(System.currentTimeMillis() + 3600000);
        String token = JWT.create()
                .withAudience(user.getId() + "")
                .withExpiresAt(date)
                .withClaim("id", user.getId())
                .withClaim("username", user.getUsername())
                .withClaim("mobileNumber", user.getMobileNumber())
                .withClaim("admin", user.getAdmin())
                .withClaim("confirmed", user.getConfirmed())
                .sign(Algorithm.HMAC256(user.getPassword()));
        return token;
    }

    @Override
    public LoginResponse login(User user) throws Exception {
        String username = user.getUsername();
        String password = user.getPassword();
        List<User> userList = userRepo.findByUsernameAndPassword(username, password);
        if (!userList.isEmpty()) {
            user = userList.get(0);
            String token = getToken(user);
            user.setPassword(null);
            return new LoginResponse(user, token);
        } else {
            throw new Exception("The user \"" + username + "\" doesn't exist or the password was incorrect.");
        }
    }

    @Override
    public boolean updateUser(User user) throws Exception {
        User u = userRepo.findUserById(user.getId());
        if (u == null) {
            throw new Exception("The user \"" + user.getUsername() + "\" doesn't exist.");
        }
        String username = user.getUsername();
        String mobileNumber = user.getMobileNumber();
        String password = user.getPassword();
        if (username != null && username.length() > 0) {
            u.setUsername(user.getUsername());
        }
        if (mobileNumber != null && mobileNumber.length() > 0) {
            u.setMobileNumber(user.getMobileNumber());
        }
        if (password != null && password.length() > 0) {
            u.setPassword(user.getPassword());
        }
        userRepo.save(u);
        return true;
    }

}
