import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { CompanyAddComponent } from './company-add/company-add.component';
import { CompanyListComponent } from './company-list/company-list.component';
import { CompanyUpdateComponent } from './company-update/company-update.component';
import { ExchangeAddComponent } from './exchange-add/exchange-add.component';
import { ExchangeListComponent } from './exchange-list/exchange-list.component';
import { IpoListComponent } from './ipo-list/ipo-list.component';
import { IpoUpdateComponent } from './ipo-update/ipo-update.component';
import { UploadExcelComponent } from './upload-excel/upload-excel.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonnModule } from '../common/common.module';

const routes: Routes = [
  { path: '', component:  CompanyListComponent },
  { path: 'company-add', component: CompanyAddComponent },
  { path: 'company-list', component: CompanyListComponent },
  { path: 'company-update', component: CompanyUpdateComponent },
  { path: 'exchange-add', component: ExchangeAddComponent },
  { path: 'exchange-list', component: ExchangeListComponent },
  { path: 'ipo-list', component: IpoListComponent },
  { path: 'ipo-update', component: IpoUpdateComponent },
  { path: 'upload-excel', component: UploadExcelComponent }
];

@NgModule({
  declarations: [
    CompanyAddComponent,
    CompanyListComponent,
    CompanyUpdateComponent,
    ExchangeAddComponent,
    ExchangeListComponent,
    IpoListComponent,
    IpoUpdateComponent,
    UploadExcelComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    CommonnModule

  ],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
