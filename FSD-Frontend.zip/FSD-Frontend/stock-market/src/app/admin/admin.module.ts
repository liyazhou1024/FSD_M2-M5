import { NgModule } from '@angular/core';
import { AdminRoutingModule } from './admin-routing.module';


@NgModule({
  imports: [
    AdminRoutingModule
  ],
  declarations: []
})
export class AdminModule { }
