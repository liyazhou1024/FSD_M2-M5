import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { ConfigService } from 'src/app/common/services/config.service';
import { CompanyService } from 'src/app/services/company.service';
import { DisplayService } from 'src/app/common/services/display.service';
import { Company } from 'src/app/models/company.model';
import { IfStmt } from '@angular/compiler';
@Component({
  selector: 'app-company-add',
  templateUrl: './company-add.component.html',
  styleUrls: ['./company-add.component.css'],
  providers: [DatePipe]
})
export class CompanyAddComponent implements OnInit {
  sectorList: any;
  stockExchangeList: [];

  addCompanyForm = new FormGroup({
    company: new FormControl(),
    ceoname: new FormControl(),
    stockCode: new FormControl(),
    sector: new FormControl(),
    other: new FormControl()
  });

  company: Company;
  courseData: any ;
  constructor(
     private configService: ConfigService,
     private companyService: CompanyService,
     private displayService: DisplayService
     ) { }

  ngOnInit() {
    this.courseData = this.configService.getSectorInfo();
    this.sectorList = this.configService.getSectorInfo();
    this.stockExchangeList = this.configService.getStockExchangeInfo();
    this.displayService.setMsg([]);
  }

  onSubmit() {
    console.log(this.sectorList);
    this.company = {
      'id': null,
      'name': this.addCompanyForm.value.company,
      'sectorId': this.addCompanyForm.value.other,
      'turnover': this.addCompanyForm.value.stockCode,
      'ceo': this.addCompanyForm.value.ceoname,
      'boardOfDirectors': 'p1, p2, p3, p4',
      'briefWriteup': this.addCompanyForm.value.sector
    }
    console.log('create company: ', this.company);
    console.log(this.addCompanyForm.value);
    if(this.addCompanyForm.value.company === null || this.addCompanyForm.value.other === null 
      || this.addCompanyForm.value.stockCode === null || this.addCompanyForm.value.ceoname === null
      || this.addCompanyForm.value.sector ===null){
        alert('All required!!!')
    } else {
      this.companyService.addCompany(this.company).subscribe(
        data => {
          if (data) {
            alert('The company has been created.')
          } else {
            alert('The company has not been created.')
          }
        },
        err => {
          console.log(err);
        }
      );
    }
  }
}
