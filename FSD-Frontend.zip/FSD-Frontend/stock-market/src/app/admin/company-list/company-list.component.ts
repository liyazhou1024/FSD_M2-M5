import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CompanyService } from 'src/app/services/company.service';
import { UserService } from 'src/app/common/services/user.service';
import { DisplayService } from 'src/app/common/services/display.service';
import { Company } from 'src/app/models/company.model';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.css']
})
export class CompanyListComponent implements OnInit {
  companies: any[];
  selectedCompany: Company;
  companyName: string;
  isAdmin: boolean;
  constructor(
    private router: Router,
    private companyService: CompanyService,
    private userService: UserService,
    private displayService: DisplayService
  ) {
    this.getCompanyList();
    this.userService.isAdmin().subscribe(
      data => {
        this.isAdmin = data;
      },
      err => {
        console.log(err);
      }
    );
    this.displayService.setMsg([]);
  }

  ngOnInit() {

  }

  addCompany() {
    console.log('addcompany');
    this.router.navigate(['/admin/company-add']);
  }

  deleteData(id: any){
    // this.router.navigate(['/company-add'], { queryParams: { search: data} });
    console.log(id);
    
      // console.log('going to deactivate company ' + this.selectedCompany['id']);
      this.companyService.deactivateCompany(id).subscribe(
        data => {
          if (data) {
            this.displayService.setMsg(['success', 'The company has been deactivated.']);
            // this.findCompany();
            this.getCompanyList();
          } else {
            this.displayService.setMsg(['error', 'The company has not been deactivated.']);
          }
        },
        err => {
          console.log(err);
        }
      );
 
  }

  getCompanyList() {
    this.companyService.getCompanyList().subscribe(
      data => {
        this.companies = data;
        console.log(this.companies);
      },
      err => {
        console.log(err);
      }
    );
  }
}
