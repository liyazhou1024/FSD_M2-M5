import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { StockExchange } from 'src/app/models/stock-exchange.model';
import { StockExchangeService } from 'src/app/services/stock-exchange.service';
import { DisplayService } from 'src/app/common/services/display.service';
import { ConfigService } from 'src/app/common/services/config.service';
@Component({
  selector: 'app-exchange-add',
  templateUrl: './exchange-add.component.html',
  styleUrls: ['./exchange-add.component.css']
})
export class ExchangeAddComponent implements OnInit {
  stockExchange: StockExchange;
  addExchangeForm = new FormGroup({
    exchange: new FormControl(),
    location: new FormControl(),
    description: new FormControl(),
  });
  constructor(
    private stockExchangeService: StockExchangeService,
    private configService: ConfigService
  ) { }

  ngOnInit() {

  }

  onSubmit() {
    console.log(123);
    this.stockExchange = {
      'id': null,
      'name': this.addExchangeForm.value.exchange,
      'brief': this.addExchangeForm.value.description,
      'contactAddress': this.addExchangeForm.value.location,
      'remarks': null
    };
    if(this.addExchangeForm.value.exchange === null || this.addExchangeForm.value.description===null 
      || this.addExchangeForm.value.location === null){
        alert('all required!!!')
    }else{
      this.stockExchangeService.addStockExchange(this.stockExchange).subscribe(
        data => {
          if (data) {
            alert('The stock exchange has been created.')
            this.stockExchangeService.getStockExchanges().subscribe(
              data => {
                this.configService.setStockExchangeInfo(data);
              },
              err => {
                console.log(err);
              }
            );
          } else {
            alert('The stock exchange has not been created')
          }
        },
        err => {
          console.log(err);
        }
      );
    }
  }
}
