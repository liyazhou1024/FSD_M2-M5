import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { StockExchangeService } from 'src/app/services/stock-exchange.service';

@Component({
  selector: 'app-exchange-list',
  templateUrl: './exchange-list.component.html',
  styleUrls: ['./exchange-list.component.css']
})
export class ExchangeListComponent implements OnInit {
  exchanges: any[];
  constructor(
    private router: Router,
    private stockExchangeService: StockExchangeService,
  ) {
    this.stockExchangeService.getStockExchanges().subscribe(
      data => {
        this.exchanges = data;
        console.log(data);
      },
      err => {
        console.log(err);
      }
    );
  }

  ngOnInit() {
  }

  addCompany() {
    console.log('addcompany');
    this.router.navigate(['/admin/exchange-add']);
  }

}
