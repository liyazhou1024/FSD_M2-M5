import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { IpoService } from 'src/app/services/ipo.service';
import { DisplayService } from 'src/app/common/services/display.service';
@Component({
  selector: 'app-ipo-list',
  templateUrl: './ipo-list.component.html',
  styleUrls: ['./ipo-list.component.css']
})
export class IpoListComponent implements OnInit {
  ipos: any[];
  page: any;
  companyList: any[] = [
    {companyName: 'IBM', stockExchanges: 'SZ', perShare: '12$', totalNum: 1000, opendate: '2020-06-01'},
    {companyName: 'alibaba', stockExchanges: 'HK', perShare: '13$', totalNum: 3000, opendate: '2019-06-01'}
  ];
  constructor(
    private router: Router,
    private ipoService: IpoService,
    private displayService: DisplayService
  ) {
    this.getPlannedIpos();
  }
  ngOnInit() {
  }

  addIpo() {
    console.log('addcompany');
  }

  editData(data: any){
    console.log(data);
  }

  getPlannedIpos() {
    this.ipoService.getPlannedIpos().subscribe(
      data => {
        this.ipos = data;
        console.log(data);
      },
      err => {
        console.log(err);
      }
    );
  }
}
