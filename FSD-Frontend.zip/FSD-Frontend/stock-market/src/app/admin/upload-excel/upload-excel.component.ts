import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { StockService } from 'src/app/services/stock.service';
import { DisplayService } from 'src/app/common/services/display.service';
@Component({
  selector: 'app-upload-excel',
  templateUrl: './upload-excel.component.html',
  styleUrls: ['./upload-excel.component.css']
})
export class UploadExcelComponent implements OnInit {
  page: any;
  file: File;
  fileName = '';
  lineNum: any;
  dateTime: any ;
  msg: any;
  logList: any[] = [
    {fileName: 'test1.xslx', user: 'terry', lineNum: 1000, date: '2020-06-01'},
    {fileName: 'test2.xslx', user: 'cherry', lineNum: 3000, date: '2019-06-01'}
  ];
  constructor(     
    private stockService: StockService,
    private displayService: DisplayService
    ) { }

  ngOnInit() {
  }

  import() {
    console.log('import');
    alert('import data');
  }

  deleteData(data: any) {
    console.log(data);
    alert('Do you delete this log?');
  }

  importStockPrice() {
    console.log('importing...');
    if (this.fileName == '') {
      this.displayService.setMsg(['error', 'Please select a File First']);
      window.scroll(0, 0);
    } else {
      this.stockService.importStockPrice(this.file).subscribe(
        data => {
          console.log(data);
          this.lineNum = data;
          this.msg = 'success', data + ' imported successfully.'
          this.displayService.setMsg(['success', data + ' imported successfully.']);
          // this.router.navigate(['/company/import-price-success']);
          this.dateTime = new Date();
        },
        err => {
          console.log(err);
        }
      );
    }
  }
  fileChange(fileInputEvent: any) {
    if (fileInputEvent.target.files.length > 0) {
      this.file = fileInputEvent.target.files[0];
      if (this.file.size / 1024 / 1024 > 3) {
        this.fileName = '';
        this.displayService.setMsg(['error', 'The size of uploaded file should be less than 3MB.']);
        window.scroll(0, 0);
        return;
      }
      this.fileName = fileInputEvent.target.files[0].name;
      this.displayService.setMsg([]);
    } else {
      this.fileName = '';
    }
  }
}


