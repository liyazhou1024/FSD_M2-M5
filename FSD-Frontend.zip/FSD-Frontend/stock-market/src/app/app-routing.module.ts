import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './common/login/login.component';
import { CompanyListComponent } from './admin/company-list/company-list.component';
import { IpoListComponent } from './user/ipo-list/ipo-list.component';
import { AuthGuard } from './common/guards/auth.guard';




const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent,},
  { path: 'admin', loadChildren:'./admin/admin.module#AdminModule', canActivate: [AuthGuard] },
  { path: 'user', loadChildren:'./user/user.module#UserModule', canActivate: [AuthGuard]},
  { path: '**', redirectTo: 'login' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
