import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { User } from '../models/user.model';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  searchForm = new FormGroup({
    searchText: new FormControl()
  });

  constructor(
    private router: Router,
    private userService: UserService
    ) { }

  ngOnInit() {
  }

  onSearch() {
    console.log(this.searchForm.value.searchText);
    // this.router.navigate(['list'], { queryParams: { search: this.searchForm.value.searchText } });
  }
  logout() {
    // console.log('logout');
    // var user: User = {
    //   'admin': false,
    //   username: '',
    //   confirmed: false
    // }
    // this.userService.setUser(user);
    this.router.navigate(['/login']);
  }
}
