import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, NgForm } from '@angular/forms';
import {Router} from '@angular/router';

import { ConfigService } from '../services/config.service';
import { DisplayService } from '../services/display.service';
import { UserService } from '../services/user.service';
import { Md5 } from 'ts-md5';
import { AdminModule } from 'src/app/admin/admin.module';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm = new FormGroup({
    userName: new FormControl(),
    password: new FormControl()
  });

  constructor(
    private router: Router,
    private userService: UserService,
    private configService: ConfigService,
    private displayService: DisplayService
    ) { }

  ngOnInit() {
    this.displayService.setMsg([]);
  }

  validateInput(): boolean {
    if (this.loginForm.value.userName === null || this.loginForm.value.password === null) {
      alert('user name or passowrd required')
      return false;
    }
    return true;
  }

  async onSubmit() {

    if (this.validateInput()) {
      var user = {
        // username: admin password: admin
        // username: user password: user
        'username': this.loginForm.value.userName.trim(),
        'password': this.loginForm.value.password.trim(),
      };
      this.displayService.setMsg([]);
      this.userService.login(user).subscribe(
        data => {
          this.userService.setUserInfo(data);
          this.configService.initConfiguration();
          if (data['user']['admin']) {
            this.router.navigate(['/admin']);
          } else {
            this.router.navigate(['/user']);
          }
        },
        err => {
          console.log(err);
          alert('password was incorrect')
        }
      )
    }

  }

  // register() {
  //   alert('Invalid user name or passowrd!');
  // }
}
