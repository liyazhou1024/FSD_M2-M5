export interface User {
  id?: number;
  username: string;
  password?: string;
  mobileNumber?: string;
  admin: boolean;
  confirmed: boolean;
}
