import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { User } from '../models/user.model';
import { UserService } from '../services/user.service';


@Component({
  selector: 'app-sub-user',
  templateUrl: './sub-user.component.html',
  styleUrls: ['./sub-user.component.css']
})
export class SubUserComponent implements OnInit {

  searchForm = new FormGroup({
    searchText: new FormControl()
  });

  constructor(
    private router: Router,
    private userService: UserService,
    ) { }

  ngOnInit() {
  }

  ManageCompany() {
    // this.router.navigate(['/company/manage-company']);
  }
  ManageExchange() {
  }

  ManageIpo() {
    // this.router.navigate(['/admin/ipo-list']);
  }

  ImportData() {
  }

  onSearch() {
    console.log(this.searchForm.value.searchText);
    this.router.navigate(['list'], { queryParams: { search: this.searchForm.value.searchText } });
  }

  logout() {
    console.log('logout');
    var user: User = {
      'admin': false,
      username: '',
      confirmed: false
    }
    this.userService.setUser(user);

    // this.newHeaders.delete('Access-Token')
    // this.userService.setUserInfo(null);

    this.router.navigate(['/login']);
  }
}
