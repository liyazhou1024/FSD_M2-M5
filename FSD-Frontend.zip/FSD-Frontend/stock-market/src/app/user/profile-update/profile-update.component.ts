import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from 'src/app/common/models/user.model';
import { UserService } from 'src/app/common/services/user.service';

@Component({
  selector: 'app-profile-update',
  templateUrl: './profile-update.component.html',
  styleUrls: ['./profile-update.component.css']
})
export class ProfileUpdateComponent implements OnInit {
  addCompanyForm = new FormGroup({
    username: new FormControl(),
    password: new FormControl(),
    confirmPassword: new FormControl(),
  });
  constructor(private activateInfo: ActivatedRoute, 
    private router: Router,
    private userService: UserService,
    ) { }
  user: User ;
  updateUser: User;
  ngOnInit() { 
    this.getUserInfo();
    this.userService.getUser()
      this.activateInfo.queryParams.subscribe(params => {
      this.addCompanyForm.setValue({
        username: this.user.username ? this.user.username : null,
        password: null,
        confirmPassword: null
      });
    });
  }
  getUserInfo(): void {
    this.userService.getUser().subscribe(
      data => {
        this.user = data;
      }
    )
  }
  onSubmit() {
    console.log(123);
    // console.log(this.addCompanyForm.value);
    if(this.addCompanyForm.value.username === null||
      this.addCompanyForm.value.password === null || this.addCompanyForm.value.confirmPassword== null ){
        alert('all required!!')
    }else if ( this.addCompanyForm.value.password !== this.addCompanyForm.value.confirmPassword ){
      alert('new password not right!!')
    } else{
        this.updateUser = {
          'id': this.user.id,
          'username': this.addCompanyForm.value.username,
          'password': this.addCompanyForm.value.password,
          'mobileNumber': '123456',
          'admin': false,
          'confirmed': true
        };
        console.log('updating user profile: ',  this.updateUser);
        this.userService.updateUser( this.updateUser).subscribe(
          data => {
            console.log(data);
            if (data) {
              alert('You have successfully updated your profile')
            }
          },
          err => {
            console.log(err);
          }
        )
     
    }

  }

}
