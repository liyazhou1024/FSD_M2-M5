import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { IpoListComponent } from './ipo-list/ipo-list.component';

import { ProfileUpdateComponent } from './profile-update/profile-update.component';

import { CommonnModule } from '../common/common.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CompareCompaniesComponent } from './compare/compare-companies.component';

const routes: Routes = [
  {path: '', component: IpoListComponent },
  {path: 'ipo-view', component: IpoListComponent },
  {path: 'compared', component:  CompareCompaniesComponent},
  {path: 'profile',  component: ProfileUpdateComponent },
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    CommonnModule
  ],
  declarations: [
    IpoListComponent,
    CompareCompaniesComponent,
    ProfileUpdateComponent
  ],
  exports: [RouterModule]

})
export class UserRoutingModule { }
