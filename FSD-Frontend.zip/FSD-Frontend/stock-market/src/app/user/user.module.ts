import { NgModule } from '@angular/core';
import { UserRoutingModule } from './user-route.module';




@NgModule({
  imports: [
    UserRoutingModule
  ],
  declarations: []
})
export class UserModule { }
