import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

constructor() { }

}

export const lazyLoadExceljs = () => import(/* webpackChunkName: "exceljs" */'exceljs/dist/exceljs.min.js');
