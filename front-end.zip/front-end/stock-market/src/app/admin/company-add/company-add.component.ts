import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-company-add',
  templateUrl: './company-add.component.html',
  styleUrls: ['./company-add.component.css']
})
export class CompanyAddComponent implements OnInit {
  addCompanyForm = new FormGroup({
    company: new FormControl(),
    ceoname: new FormControl(),
    ipoDate: new FormControl(),
    stockCode: new FormControl(),
    sector: new FormControl(),
    other: new FormControl()
  });
  courseId: any = 'ibmcic';
  courseData: any[] = [{id: '1', courseName: 'ibmgbs'}, {id: '2', courseName: 'ibmcd'}];
  constructor(private activateInfo: ActivatedRoute, private router: Router) { }

  ngOnInit() {
      this.activateInfo.queryParams.subscribe(params => {
      this.addCompanyForm.setValue({
        company: params.search ? params.search : null,
        ceoname: 'qq',
        ipoDate: 'qq',
        stockCode: 'qq',
        sector: 'qq',
        other: 'qq'
      });
    });
  }

  onSubmit() {
    console.log(123);
    console.log(this.addCompanyForm.value);
    this.router.navigate(['/company-list']);
  }
}
