import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-exchange-list',
  templateUrl: './exchange-list.component.html',
  styleUrls: ['./exchange-list.component.css']
})
export class ExchangeListComponent implements OnInit {

  constructor( private activateInfo: ActivatedRoute, private router: Router) { }
  exchangeList: any[] = [{exchangeName: 'NYK', loction: 'US', description: 'test'},
  {exchangeName: 'SL', loction: 'CN', description: 'test1'}];

  ngOnInit() {
  }

  addCompany() {
    console.log('addcompany');
    this.router.navigate(['/exchange-add']);
  }

  editData(data: any){
    this.router.navigate(['/exchange-add'], { queryParams: { search: data} });
    console.log(data);
  }
}
