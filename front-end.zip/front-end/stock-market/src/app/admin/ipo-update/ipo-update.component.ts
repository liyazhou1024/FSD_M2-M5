import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-ipo-update',
  templateUrl: './ipo-update.component.html',
  styleUrls: ['./ipo-update.component.css']
})
export class IpoUpdateComponent implements OnInit {
  addIpoForm = new FormGroup({
    company: new FormControl(),
    exchange: new FormControl(),
    perPrice: new FormControl(),
    totalnum: new FormControl(),
    opendate: new FormControl(),
  });
  courseData: any[] = [{id: '1', courseName: 'ibmgbs'}, {id: '2', courseName: 'ibmcd'}];
  constructor(private activateInfo: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.activateInfo.queryParams.subscribe(params => {
      this.addIpoForm.setValue({
        company: params.search ? params.search : null,
        exchange: 'qq',
        perPrice: 'qq',
        totalnum: 'qq',
        opendate: 'qq'
      });
    });
  }

  onSubmit() {
    console.log(123);
    console.log(this.addIpoForm.value);
    this.router.navigate(['/company-list']);
  }
}
