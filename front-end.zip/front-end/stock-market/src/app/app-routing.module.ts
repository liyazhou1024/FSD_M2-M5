import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './common/login/login.component';
import { CompanyListComponent } from './admin/company-list/company-list.component';
import { IpoListComponent } from './user/ipo-list/ipo-list.component';



const routes: Routes = [
  { path: '', component: LoginComponent , pathMatch: 'full' },
  {
    path: 'admin',
    component: CompanyListComponent,
    pathMatch: 'full',
  },
  {
    path: 'user',
    component: IpoListComponent,
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
