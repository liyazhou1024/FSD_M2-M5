import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-sub-user',
  templateUrl: './sub-user.component.html',
  styleUrls: ['./sub-user.component.css']
})
export class SubUserComponent implements OnInit {

  searchForm = new FormGroup({
    searchText: new FormControl()
  });

  constructor(private router: Router) { }

  ngOnInit() {
  }

  ManageCompany() {
    // this.router.navigate(['/company/manage-company']);
  }
  ManageExchange() {
  }

  ManageIpo() {
    // this.router.navigate(['/admin/ipo-list']);
  }

  ImportData() {
  }

  onSearch() {
    console.log(this.searchForm.value.searchText);
    this.router.navigate(['list'], { queryParams: { search: this.searchForm.value.searchText } });
  }
}
