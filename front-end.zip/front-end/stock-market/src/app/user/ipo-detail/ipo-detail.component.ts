import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ipo-detail',
  templateUrl: './ipo-detail.component.html',
  styleUrls: ['./ipo-detail.component.css']
})
export class IpoDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
