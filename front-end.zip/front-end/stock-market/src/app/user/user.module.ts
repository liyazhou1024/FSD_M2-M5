import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IpoDetailComponent } from './ipo-detail/ipo-detail.component';
import { IpoListComponent } from './ipo-list/ipo-list.component';
import { DetailCompareComponent } from './detail-compare/detail-compare.component';
import { ProfileUpdateComponent } from './profile-update/profile-update.component';
import { ChartComponent } from './chart/chart.component';

import { UserService } from './user.service';
import { UserRouteRoutes } from './user-route.routing';
import { CommonnModule } from '../common/common.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  imports: [
    CommonModule,
    UserRouteRoutes,
    CommonnModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    IpoDetailComponent,
    IpoListComponent,
    DetailCompareComponent,
    ProfileUpdateComponent,
    ChartComponent
  ],
  providers: [UserService],
  entryComponents: [ChartComponent]
})
export class UserModule { }
