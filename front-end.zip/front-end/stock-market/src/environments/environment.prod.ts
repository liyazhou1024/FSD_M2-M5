export const environment = {
  production: true,
  apiBasePath: 'http://localhost:9023',
};
