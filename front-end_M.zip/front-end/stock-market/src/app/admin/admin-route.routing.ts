import { Routes, RouterModule } from '@angular/router';
import { CompanyAddComponent } from './company-add/company-add.component';
import { CompanyListComponent } from './company-list/company-list.component';
import { CompanyUpdateComponent } from './company-update/company-update.component';
import { ExchangeAddComponent } from './exchange-add/exchange-add.component';
import { ExchangeListComponent } from './exchange-list/exchange-list.component';
import { IpoListComponent } from './ipo-list/ipo-list.component';
import { IpoUpdateComponent } from './ipo-update/ipo-update.component';
import { UploadExcelComponent } from './upload-excel/upload-excel.component';

const routes: Routes = [
  {
    path: 'company-add',
    component: CompanyAddComponent
    },
    {
    path: 'company-list',
    component: CompanyListComponent
    },
    {
    path: 'company-update',
    component: CompanyUpdateComponent
    },
    {
      path: 'exchange-add',
      component: ExchangeAddComponent
    },
    {
      path: 'exchange-list',
      component: ExchangeListComponent
    },
    {
      path: 'ipo-list',
      component: IpoListComponent
    },
    {
      path: 'ipo-update',
      component: IpoUpdateComponent
    },
    {
    path: 'upload-excel',
    component: UploadExcelComponent
    }
];

export const AdminRouteRoutes = RouterModule.forChild(routes);
