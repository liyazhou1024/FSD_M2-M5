import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { CompanyAddComponent } from './company-add/company-add.component';
import { CompanyListComponent } from './company-list/company-list.component';
import { CompanyUpdateComponent } from './company-update/company-update.component';
import { ExchangeAddComponent } from './exchange-add/exchange-add.component';
import { ExchangeListComponent} from './exchange-list/exchange-list.component';
import { IpoListComponent } from './ipo-list/ipo-list.component';
import { IpoUpdateComponent } from './ipo-update/ipo-update.component';
import { UploadExcelComponent } from './upload-excel/upload-excel.component';

import { AdminService } from './admin.service';

import { AdminRouteRoutes } from './admin-route.routing';
import { CommonnModule } from '../common/common.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    AdminRouteRoutes,
    FormsModule,
    ReactiveFormsModule,
    CommonnModule
  ],
  declarations: [
    CompanyAddComponent,
    CompanyListComponent,
    CompanyUpdateComponent,
    ExchangeAddComponent,
    ExchangeListComponent,
    IpoListComponent,
    IpoUpdateComponent,
    UploadExcelComponent
  ],
  providers: [AdminService]
})
export class AdminModule { }
