import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-upload-excel',
  templateUrl: './upload-excel.component.html',
  styleUrls: ['./upload-excel.component.css']
})
export class UploadExcelComponent implements OnInit {
  page: any;
  logList: any[] = [
    {fileName: 'test1.xslx', user: 'terry', lineNum: 1000, date: '2020-06-01'},
    {fileName: 'test2.xslx', user: 'cherry', lineNum: 3000, date: '2019-06-01'}
  ];
  constructor( private activateInfo: ActivatedRoute, private router: Router) { }

  ngOnInit() {
  }

  import() {
    console.log('import');
    alert('import data');
  }

  deleteData(data: any) {
    console.log(data);
    alert('Do you delete this log?');
  }
}


