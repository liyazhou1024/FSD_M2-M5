import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  searchForm = new FormGroup({
    searchText: new FormControl()
  });

  constructor(private router: Router) { }

  ngOnInit() {
  }

  onSearch() {
    console.log(this.searchForm.value.searchText);
    // this.router.navigate(['list'], { queryParams: { search: this.searchForm.value.searchText } });
  }

}
