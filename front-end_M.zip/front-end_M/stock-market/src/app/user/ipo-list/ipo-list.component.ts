import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-ipo-list',
  templateUrl: './ipo-list.component.html',
  styleUrls: ['./ipo-list.component.css']
})
export class IpoListComponent implements OnInit {

  companyList: any[] = [
    {companyName: 'IBM', stockExchanges: 'SZ', perShare: '12$', totalNum: 1000, opendate: '2020-06-01'},
    {companyName: 'alibaba', stockExchanges: 'HK', perShare: '13$', totalNum: 3000, opendate: '2019-06-01'}
  ];
  constructor( private activateInfo: ActivatedRoute, private router: Router) { }

  ngOnInit() {
  }

}
