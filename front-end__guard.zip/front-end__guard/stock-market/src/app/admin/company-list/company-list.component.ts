import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.css']
})
export class CompanyListComponent implements OnInit {

  page: any;
  companyList: any[] = [{companyName: 'ibm', stockExchanges: 'sz', description: 'test'},
  {companyName: 'alibaba', stockExchanges: 'hk', description: 'test1'}];
  constructor( private activateInfo: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    // this.activateInfo.queryParams.subscribe(params => {
    //   this.page = params.search;
    //   console.log(this.page);
    // });
  }

  addCompany() {
    console.log('addcompany');
    this.router.navigate(['/company-add']);
  }

  editData(data: any){
    this.router.navigate(['/company-add'], { queryParams: { search: data} });
    console.log(data);
  }
}
