import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-update',
  templateUrl: './company-update.component.html',
  styleUrls: ['./company-update.component.css']
})
export class CompanyUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
