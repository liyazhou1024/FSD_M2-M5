import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-exchange-add',
  templateUrl: './exchange-add.component.html',
  styleUrls: ['./exchange-add.component.css']
})
export class ExchangeAddComponent implements OnInit {
  addExchangeForm = new FormGroup({
    exchange: new FormControl(),
    location: new FormControl(),
    description: new FormControl(),
  });
  constructor(private activateInfo: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.activateInfo.queryParams.subscribe(params => {
      this.addExchangeForm.setValue({
        exchange: params.search ? params.search : null,
        location: 'qq',
        description: 'qq',
      });
    });
  }

  onSubmit() {
    console.log(123);
    this.router.navigate(['/exchange-list']);
  }
}
