import { Routes, RouterModule } from '@angular/router';
import { DetailCompareComponent } from './detail-compare/detail-compare.component';
import { ProfileUpdateComponent } from './profile-update/profile-update.component';
import { IpoListComponent } from './ipo-list/ipo-list.component';

const routes: Routes = [
  {
    path: 'ipo-view',
    component: IpoListComponent
  },
  {
    path: 'compared',
    component: DetailCompareComponent
  },
  {
    path: 'profile',
    component: ProfileUpdateComponent
  },
];

export const UserRouteRoutes = RouterModule.forChild(routes);
